import java.util.Scanner;
import java.util.Random;
public class Lab2p1 {
	public static void main(String[] args)
	 {
	Scanner sc= new Scanner(System.in);
	int choice;
	Lab2p1 p1= new Lab2p1();
	do {
		System.out.println("Perform the following methods:");
		System.out.println("1: multiplication test");
		System.out.println("2: quotient using division by subtraction");
		System.out.println("3: remainder using division by subtraction");
		System.out.println("4: count the number of digits");
		System.out.println("5: position of a digit");
		System.out.println("6: extract all odd digits");
		System.out.println("7: quit");
	choice  = sc.nextInt();
	switch (choice) {
	 case 1: p1.mulTest();
	 break;
	 
	 case 2: 
		 System.out.println("m:");
		 int userInput1 = sc.nextInt();
		 System.out.println("n:");
		 int userInput2 = sc.nextInt();
		 System.out.println(userInput1  +"/"+ userInput2 +"=" + p1.divide(userInput1,userInput2));
	 break;
	 
	 case 3: 
		 System.out.println("m:");
		 int userInput3 = sc.nextInt();
		 System.out.println("n:");
		 int userInput4 = sc.nextInt();
		 System.out.println(userInput3 + "%"+ userInput4 +"="+ modulus(userInput3,userInput4));
	 break;
	 
	 case 4:
		 System.out.println("Enter no:");
		 int userInput5 = sc.nextInt();
		 int result = countDigits(userInput5);
		 if(result == -1 )
			 System.out.println("n :"+ userInput5 + " - Error input!!");
		 else
			 System.out.println("n :"+ userInput5 +" -count = "+ result);
	 break;
	 case 5:
		 System.out.println("Enter n:");
		 int userInput6= sc.nextInt();
		 System.out.println("Enter digit:");
		 int userInput7 = sc.nextInt();
		 System.out.println("position: " + p1.position(userInput6, userInput7));
	 break;
	 case 6:
		 System.out.println("Enter number:");
		 int userInput8 = sc.nextInt();
		 if(userInput8 <= 0)
			 System.out.println("Error input!!!");
		 else
		 System.out.println("oddDigits = "+ p1.extractOddDigits(userInput8));
		 break;
	 case 7: 
		 System.out.println("Program terminating....");
	}
	} while (choice < 7);
	 }
	 
	public static void mulTest() {
		Random rand = new Random();
		Scanner sc = new Scanner(System.in);
		int counter=0;
		int correctCount=0;
		int r1;
		int r2;
		while(counter<5) {
			r1= rand.nextInt(9)+1;
			r2= rand.nextInt(9)+1;
		System.out.println("How much is "+r1+" times "+ r2 +"?");
		int userInput = sc.nextInt();
		if(userInput == r1*r2 )
			correctCount++;
		counter++;
		}
		
		System.out.println(correctCount + "answers out of 5 are correct");
	}
	
	public static int divide(int m,int n) {
		int counter= 0;
		if(m>=n) {
			while(m>0 && m>=n) {
				m = m-n;
				counter++;
			}
		}
		
		return counter;
	}
	public static int modulus(int m,int n) {
		if (m==n)
			return 0;
		
		else if(m>n) {
			while(m>n) {
				m = m-n;
			}
			if(m==n)
				return 0;
			else
				return m;
		}
		
		else
			return m;
		}
	
	public static int countDigits(int n )
	{	int count=1 ; 
		if (n<=0)
			return -1;
		else 
		{
			while((n/10)%10 !=0 ) {
				n = n/10;
				count++;
			}
			return count;
		}
	}
	
	public static int position(int n, int digit) 
	{
		int position = 1;
		while(n >0) {
			if(n%10 == digit)
				{return position;}
			n= n/10;
			position++;
		}
		return -1;
		
	}
	
	public static long extractOddDigits(long n)
	{	if(n<=0)
		return 0;
		else {
		long digit = 0;
		long counter= 1;
		while(n>0) {
			if(n%2!= 0 ) {
				digit+= (n%10)*counter;
				counter=counter*10;
			}
			n = n/10;
		}
		if(digit== 0)
			return -1;
		else
			return digit;
	}
		
}

}